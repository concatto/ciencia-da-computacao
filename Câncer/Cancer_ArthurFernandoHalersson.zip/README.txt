Disciplina de Simulação Discreta de Sistemas (2017/2)
Professor: André Luiz Maciel Santana

Projeto: Simulação do Crescimento de Tumores Malignos
Integrantes: Arthur Passos, Fernando Concatto e Hálersson Paris 
