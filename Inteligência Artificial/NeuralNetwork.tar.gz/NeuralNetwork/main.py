import numpy as np
import pandas as pd
from neural_network import NeuralNetwork
from layers import Layer


def load_dataset(csv_file, input_dimension):
	data = pd.read_csv(csv_file)
	columns = data.columns.tolist()
	X_names = columns[0:input_dimension]
	y_names = columns[input_dimension:]

	X = np.matrix(data[X_names])
	y = np.matrix(data[y_names])

	return X, y


X, y = load_dataset("CasosArtrite2.csv", 17)

nn = NeuralNetwork(learning_rate=0.1)
nn.add_layer(Layer(20))
nn.add_layer(Layer(15))

nn.fit(X, y, epochs=100000)

