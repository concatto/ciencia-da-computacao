#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <SFML/Graphics.hpp>

using namespace std;

int main() {
    sf::RenderWindow janela(sf::VideoMode(1100, 900), "SFML");

    cout << "Hello World!" << endl;

    while (true) {
        janela.clear();

        janela.display();
    }

    return 0;
}
