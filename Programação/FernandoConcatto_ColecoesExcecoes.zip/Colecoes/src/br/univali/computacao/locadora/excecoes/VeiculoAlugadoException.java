package br.univali.computacao.locadora.excecoes;

@SuppressWarnings("serial")
public class VeiculoAlugadoException extends Exception {

	public VeiculoAlugadoException(String message) {
		super(message);
	}

}
