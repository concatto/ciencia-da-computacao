package br.univali.computacao.locadora.excecoes;

@SuppressWarnings("serial")
public class NomeNuloException extends Exception {

	public NomeNuloException(String message) {
		super(message);
	}

}
