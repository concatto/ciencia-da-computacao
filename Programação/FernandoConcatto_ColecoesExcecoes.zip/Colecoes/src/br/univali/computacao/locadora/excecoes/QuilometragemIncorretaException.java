package br.univali.computacao.locadora.excecoes;

@SuppressWarnings("serial")
public class QuilometragemIncorretaException extends Exception {

	public QuilometragemIncorretaException(String message) {
		super(message);
	}

}
